
Canvas English Trainer (PWA) - Downloaded package
-----------------------------------------------

ファイル一覧:
- english_canvas_app.html   ← メインアプリ（これをブラウザで開いてください）
- manifest.json             ← PWA 設定ファイル
- sw.js                     ← Service Worker（オフライン対応）
- icon-192.png              ← アイコン（192px）
- icon-512.png              ← アイコン（512px）

使い方（ローカルで使う簡単な手順）:
1) フォルダをそのまま保存してください（または解凍）。
2) ローカルサーバを立てて起動してください（推奨: VS Code + Live Server）。
   - Live Server を使うと `http://localhost:5500/english_canvas_app.html` のように開けます。
   - PWA（Service Worker）は localhost または HTTPS 環境で動きます。
3) ブラウザで `english_canvas_app.html` を開きます。
4) メニューで「ホーム画面に追加」や「インストール」を選ぶとアプリ風に使えます。
5) Listening（ニュース）は組み込みの TTS（SpeechSynthesis）で英語→日本語を自動再生します。

注意点:
- 発音認識（マイク入力）は Chrome/Edge などでの動作を推奨します。
- より自然な音声ファイル（MP3/WAV）を使いたい場合は、アプリの Listening 部分で音声ファイルを指定することもできます。
